namespace RuntimeHandle
{
    /**
     * Created by Peter @sHTiF Stefcek 20.10.2020
     */
    public enum HandleSnappingType
    {
        ABSOLUTE,
        RELATIVE
    }
}