namespace RuntimeHandle
{
    /**
     * Created by Peter @sHTiF Stefcek 20.10.2020
     */
    public enum HandleAxes
    {
        X,
        Y,
        Z,
        XY,
        XZ,
        YZ,
        XYZ
    }
}